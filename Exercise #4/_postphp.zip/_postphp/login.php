<?php
session_start();
$allowedUsers = ["Gozo", "LaTorre", "Tinoy", "Lupiga"];
$validPassword = "12345";

$error = "";
$loggedIn = false;
$username = "";

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    if (in_array($username, $allowedUsers) && $password === $validPassword) {
        $_SESSION['loggedIn'] = true;
        $_SESSION['username'] = $username;
        $loggedIn = true;

        // Optional: auto-redirect to index.html after 3 seconds
        header("location: index.html");
    } else {
        $error = "Invalid username or password!";
    }
} else {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Result</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 flex items-center justify-center h-screen text-white">

<?php if ($loggedIn): ?>
    <div class="text-center">
        <h1 class="text-3xl font-bold mb-4">Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
        <p class="text-gray-300 mb-4">You will be redirected to your portfolio shortly.</p>
        <p class="text-gray-400 text-sm">URL GET parameters are visible during this time.</p>
        <a href="index.html?username=<?php echo $username; ?>&password=<?php echo $password; ?>" class="bg-red-600 hover:bg-red-700 p-2 rounded font-bold mt-4 inline-block">Go Now</a>
<?php else: ?>
    <div class="bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-md text-center">
        <p class="bg-red-600 text-white p-2 mb-4 rounded"><?php echo $error; ?></p>
        <a href="login.html" class="bg-red-600 hover:bg-red-700 p-2 rounded font-bold">Back to Login</a>
    </div>
<?php endif; ?>

</body>
</html>
