<?php
session_start();

// VALID USERNAME AND PASSWORD PAIRS
$users = [
    "Gozo"    => "pass123",
    "LaTorre" => "hello456",
    "Tinoy"   => "secret789",
    "Lupiga"  => "mypassword"
];

$error = "";
$username = "";

// FORM SUBMISSION HANDLING
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    if (isset($users[$username]) && $users[$username] === $password) {
        $_SESSION['loggedIn'] = true;
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}

?>

<!-- HTML LOGIN FORM -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 flex items-center justify-center h-screen text-white">

  <main class="w-full max-w-md">
    <section class="bg-gray-800 p-8 rounded-lg shadow-lg">
      
      <!-- HEADER -->
      <header class="mb-6">
        <h1 class="text-2xl font-bold text-red-500 text-center">Login</h1>
      </header>

      <!-- LOGIN FORM -->
      <form method="post" action="login.php">       
        <!-- USERNAME -->
        <div class="mb-4">
          <label for="username" class="block mb-2">Username</label>
          <input type="text" id="username" name="username" 
            class="w-full p-2 rounded text-black" 
            value="<?php echo htmlspecialchars($username); ?>"
            required>
        </div>
        <!-- PASSWORD -->
        <div class="mb-4">
          <label for="password" class="block mb-2">Password</label>
          <input type="password" id="password" name="password" 
            class="w-full p-2 rounded text-black" required>
        </div>

        <!-- ERROR MESSAGE -->
        <?php if ($error): ?>
          <p class="text-red-500 mb-4 text-center"><?php echo $error; ?></p>
        <?php endif; ?>

        <!-- LOGIN BUTTON -->
        <button type="submit" 
          class="w-full bg-red-600 hover:bg-red-700 p-2 rounded font-bold">
          Log In
        </button>
      </form>
    </section>

    <!-- FOOTER -->
    <footer class="mt-6 text-center text-gray-400 text-sm">
      GROUP 4 GRYFFINDOR, IT - 3K<br>
      Integrative Programming and Technologies 1
    </footer>
  </main>

</body>
</html>
