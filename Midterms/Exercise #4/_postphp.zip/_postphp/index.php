<?php
session_start();

// Protect the page
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Portfolio</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@300;400;700&display=swap');

    :root {
      --netflix-red: #e50914;
      --netflix-dark: #141414;
      --netflix-light: #f3f3f3;
    }

    body {
      font-family: 'Roboto', sans-serif;
      background-color: var(--netflix-dark);
      color: var(--netflix-light);
    }

    .logo-font {
      font-family: 'Bebas Neue', cursive;
    }

    .hero {
       background: linear-gradient(to right, rgba(0,0,0,0.7) 30%, rgba(0,0,0,0.1) 100%),
      url(img/GRYFFINDOR1.jpg) no-repeat center center;
       background-size: cover;
     height: 90vh;
}


    .member-card {
      transition: transform 0.3s ease;
    }
    .member-card:hover {
      transform: scale(1.02);
    }
  </style>
</head>
<body> 

<!-- NAVBAR -->
<header class="fixed top-0 w-full z-50 bg-">
  <nav class="container mx-auto px-6 py-4 flex justify-between items-center">
    <div class="flex items-center">
      <span class="logo-font text-3xl text-red-600 mr-10">GRYFFINDOR</span>
      <ul class="hidden md:flex space-x-6 items-center">
        <li><a href="#" class="hover:text-red-500">Home</a></li>
        <li><a href="#members" class="hover:text-red-500">Members</a></li>
      </ul>
    </div>
  </nav>
</header>

<!-- MAIN -->
<main>

  <!-- INTRODUCTION SECTION -->
  <section class="hero flex items-center">
    <div class="container mx-auto px-1">
      <h1 class="text-5xl font-bold text-red-600 logo-font" style="font-size: 180px;">Group 4 <br> Gryffindor</h1>
      <p class="text-lg max-w-2xl text-gray-300" style="font-size: 25px;">
        Welcome, <span class="text-red-500 font-bold"><?php echo $_SESSION['username']; ?></span>! <br>
        We are a group of passionate IT students who share the same drive for creativity, growth, 
        and learning. From exploring design and programming to taking on leadership and challenges, 
        we aim to support each other while honing our individual strengths. Just like our house name, 
        Gryffindor, we value courage, determination, and the spirit to keep moving forward together.
      </p>
    </div>
  </section>

  <!-- MEMBERS SECTION -->
  <section id="members" class="pb-10 mb-3 items-center">
    <div class="container mx-auto px-6">
      <h2 class="text-3xl font-bold mb-8 pl-4 border-l-4 border-red-600">GROUP MEMBERS</h2>

      <!-- MEMBERS CARDS -->
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        
        <article class="member-card bg-gray-800 rounded overflow-hidden shadow-lg">
          <a href="krizzy.html">
            <img src="img/krizzy3.jpg" alt="Krizzy Shane T. Gozo" class="mem1">
            <div class="p-4">
              <h3 class="text-xl font-bold">Krizzy Shane T. Gozo</h3>
              <p class="text-gray-400">Group Leader</p>
            </div>
          </a>
        </article>
        
        <article class="member-card bg-gray-800 rounded overflow-hidden shadow-lg">
          <a href="andrey.html">
            <img src="img/andrey.jpg.jpeg" alt="Andrey Kurt L. La Torre" class="mem2">
            <div class="p-4">
              <h3 class="text-xl font-bold">Andrey Kurt L. La Torre</h3>
              <p class="text-gray-400">Member</p>
            </div>
          </a>
        </article>

        <article class="member-card bg-gray-800 rounded overflow-hidden shadow-lg">
          <a href="shaina.html">
            <img src="img/shaina.jpeg" alt="Shaina D. Tinoy" class="mem3">
            <div class="p-4">
              <h3 class="text-xl font-bold">Shaina D. Tinoy</h3>
              <p class="text-gray-400">Member</p>
            </div>
          </a>
        </article>

        <article class="member-card bg-gray-800 rounded overflow-hidden shadow-lg">
          <a href="edmark.html">
            <img src="img/edmark.jpeg" alt="Edmark A. Lupiga" class="mem4">
            <div class="p-4">
              <h3 class="text-xl font-bold">Edmark A. Lupiga</h3>
              <p class="text-gray-400">Member</p>
            </div>
          </a>
        </article>

      </div>
    </div>
  </section>
</main>

<!-- FOOTER -->
<footer class="bg-gray-900 text-center py-6 mt-10">
  <p class="text-gray-400 mb-4"> Group 4 Gryffindor. IT - 3K.</p>
  <a href="logout.php" 
     class="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg shadow-lg font-semibold transition duration-300">
     Logout
  </a>
</footer>

</body>
</html>